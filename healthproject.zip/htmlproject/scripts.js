document.addEventListener('DOMContentLoaded', () => {
    fetch('https://api.example.com/patient-data')
        .then(response => response.json())
        .then(data => {
            // Populate patient information
            // ...

            // Example data for chart
            const ctx = document.getElementById('bloodPressureChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.months, // Replace with actual data
                    datasets: [{
                        label: 'Blood Pressure',
                        data: data.pressureValues, // Replace with actual data
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true
                }
            });
        })
        .catch(error => console.error('Error fetching data:', error));
});
